<script setup lang="ts">
import CpuDie from '@/components/common/CpuDie.vue'
import EditableValue from '@/components/common/EditableValue.vue'

import {computed, onMounted, ref} from 'vue'
import {Message} from '@arco-design/web-vue'
import {CPU, type CpuInfo, Power, RyzenSmu} from '@/utils/bridge.ts'
import {useConfigStore} from '@/stores/config'
import {useSystemInfoStore} from '@/stores/systemInfo'
import type {CpuProfileDataType} from '@/types/config'
import {CPU_PROFILE_DEFAULTS} from '@/constants'

const loading = ref(false)
const configStore = useConfigStore()
const systemInfoStore = useSystemInfoStore()


const cpuInfo = ref<CpuInfo | null>(null)

onMounted(async () => {
  try {
    const res = await CPU.GetCpuInfo()
    if (res.Success) cpuInfo.value = res.Data
  } catch {
    // 桥接不可用时保持默认展示
  }
})

// 使用 computed 来简化对配置项的访问，并确保响应性
const CPUData = computed(() => configStore.config?.Cpu)
const SmuData = computed(() => configStore.config?.Smu)
const cpuStats = computed(() => systemInfoStore.cpuStats)

/** 实时状态进度条: 标签/取值文本/占比宽度/配色 */
const cpuMetrics = computed(() => {
  const s = cpuStats.value
  const pct = (v: number, max: number) => `${Math.min((v / max) * 100, 100)}%`
  return [
    {
      label: '频率',
      text: s?.FrequencyMhz ? (s.FrequencyMhz / 1000).toFixed(2) : '0.00',
      unit: 'GHz',
      width: s?.FrequencyMhz ? pct(s.FrequencyMhz, activeProfile.value.CpuMaxFrequency || 5000) : '0%',
      barClass: 'bg-cyber-purple',
    },
    {
      label: '电压',
      text: s?.Voltage ? s.Voltage.toFixed(3) : '0.000',
      unit: 'V',
      width: s?.Voltage ? pct(s.Voltage, 1.5) : '0%',
      barClass: 'bg-cyber-purple',
    },
    {
      label: '使用率',
      text: String(s?.Usage || 0),
      unit: '%',
      width: `${s?.Usage || 0}%`,
      barClass: 'bg-[#3B82F6]',
    },
    {
      label: '温度',
      text: String(s?.Temperature || 0),
      unit: '°C',
      width: `${Math.min(s?.Temperature || 0, 100)}%`,
      barClass: 'bg-cyber-purple',
    },
  ]
})

// 分核心降压模式: 常规设置启用后, CO 滑条替换为提示, 应用时逐核心写入分核数值
const perCoreMode = computed(() => configStore.config?.App.CpuCurveOptimizerPerCore ?? false)

// 页面内部交互状态
const selectedProfile = ref('default')

// 配置文件卡片: 从配置恢复上次选中的档位（不覆盖已保存的值）
const profiles = [
  { key: 'default', title: '默认配置', desc: '平衡性能与功耗' },
  { key: 'performance', title: '高性能模式', desc: '释放最大性能' },
  { key: 'saving', title: '节能模式', desc: '降低功耗与温度' },
  { key: 'custom', title: '自定义配置', desc: '自定义参数设置' },
] as const

// 从配置恢复上次选中的档位（不覆盖已保存的值）
if (CPUData.value?.CpuProfile) {
  selectedProfile.value = CPUData.value.CpuProfile
}

// 档位名 -> 配置块字段名（config.yaml 中 Cpu 下的 Default/Performance/Saving/Custom）
function profileKey(profile: string): 'Default' | 'Performance' | 'Saving' | 'Custom' {
  const map: Record<string, 'Default' | 'Performance' | 'Saving' | 'Custom'> = {
    default: 'Default',
    performance: 'Performance',
    saving: 'Saving',
    custom: 'Custom',
  }
  return map[profile] ?? 'Default'
}

// 当前选中档位的参数块（滑块直接绑定它；切换档位即切换绑定的数据源）
const activeProfile = computed<CpuProfileDataType>(() => {
  const cpu = CPUData.value
  return (cpu?.[profileKey(selectedProfile.value)] ?? cpu?.Default) as CpuProfileDataType
})

// 切换档位：只改选中标记，界面滑块绑定的 activeProfile 随之指向该档位块
function selectProfile(profile: string) {
  selectedProfile.value = profile
  if (CPUData.value) CPUData.value.CpuProfile = profile
}

// 统一应用逻辑: best-effort——单步失败记录并继续, 最后保存配置并汇总结果。
// 不做"全有全无": 单点失败(如 SMU 邮箱异常)不应让已生效的功耗/温度设置整体丢失配置。
async function handleApplyAll() {
  if (!CPUData.value || !activeProfile.value) return
  loading.value = true
  try {
    const failures: string[] = []
    // 1. 设置长时功耗限制 (PL1)
    const longPowerRes = await CPU.SetCpuLongPower(activeProfile.value.CpuLongPower)
    if (!longPowerRes.Success) {
      failures.push(longPowerRes.Message || '长时功耗限制设置失败')
    }
    // 2. 设置短时功耗限制 (PL2)
    const shortPowerRes = await CPU.SetCpuShortPower(activeProfile.value.CpuShortPower)
    if (!shortPowerRes.Success) {
      failures.push(shortPowerRes.Message || '短时功耗限制设置失败')
    }
    // 3. 设置温度墙
    const tempWallRes = await CPU.SetCPUTempWall(activeProfile.value.CpuTempWall)
    if (!tempWallRes.Success) {
      failures.push(tempWallRes.Message || '温度墙设置失败')
    }
    // 4. 设置最大频率
    const maxFreqRes = await Power.SetCPUMaxFrequency(activeProfile.value.CpuMaxFrequency)
    if (!maxFreqRes.Success) {
      failures.push(maxFreqRes.Message || '最大频率设置失败')
    }
    // 5. 设置睿频开关
    const turboRes = activeProfile.value.CpuTurbo
      ? await Power.EnableTurbo()
      : await Power.DisableTurbo()
    if (!turboRes.Success) {
      failures.push(turboRes.Message || (activeProfile.value.CpuTurbo ? '睿频开启失败' : '睿频关闭失败'))
    }
    // 6. 核心电压偏移: 分核模式下逐核心写入已保存的分核数值 (列表为空则跳过), 否则保持全核偏移
    //    分核失败只汇总计数, 不逐核 toast, 避免十几核时消息刷屏
    if (configStore.config?.Smu) {
      if (perCoreMode.value) {
        const perCore = configStore.config.Smu.CurveOptimizerPerCore
        let failedCores = 0
        let firstError = ''
        for (let i = 0; i < perCore.length; i++) {
          const curveRes = await RyzenSmu.SetCurveOptimizerPerCore(i, perCore[i] ?? 0)
          if (!curveRes.Success) {
            failedCores++
            if (!firstError) firstError = curveRes.Message || `核心 ${i} 电压偏移设置失败`
          }
        }
        if (failedCores > 0) {
          failures.push(`${failedCores} 个核心电压偏移失败 (${firstError})`)
        }
      } else {
        const curveRes = await RyzenSmu.SetCurveOptimizerAll(configStore.config.Smu.CurveOptimizerAll)
        if (!curveRes.Success) {
          failures.push(curveRes.Message || '核心电压偏移设置失败')
        }
      }
    }

    // 7. 保存主配置（含当前档位块参数与选中档位，供开机自启等使用）。
    //    无论单项成败都保存: 已生效项的配置不因个别失败而整体丢失。
    const saveRes = await configStore.saveConfig()
    if (!saveRes?.Success) {
      Message.error(saveRes?.Message || '设置保存失败')
      return
    }

    if (failures.length === 0) {
      Message.success('设置应用成功')
    } else {
      Message.warning(`配置已保存，${failures.length} 项应用失败：${failures.join('；')}`)
    }
  } catch {
    Message.error('应用设置失败，请检查桥接服务。')
  } finally {
    loading.value = false
  }
}

// 重置当前选中档位的出厂默认参数 (不切换档位)
async function handleReset() {
  const key = profileKey(selectedProfile.value)
  const defaults = CPU_PROFILE_DEFAULTS[key]
  if (!CPUData.value || !defaults) return
  Object.assign(CPUData.value[key], defaults)
  try {
    const saveRes = await configStore.saveConfig()
    const profileTitle = profiles.find((p) => p.key === selectedProfile.value)?.title ?? ''
    if (saveRes?.Success) {
      Message.info(`「${profileTitle}」参数已恢复为出厂默认`)
    } else {
      Message.error(saveRes?.Message || '重置值保存失败')
    }
  } catch {
    Message.error('重置值保存失败')
  }
}

// 取消修改：强制从后端重新加载原始配置
async function handleCancel() {
  try {
    await configStore.fetchConfig(true)
    selectedProfile.value = CPUData.value?.CpuProfile ?? 'default'
    Message.info('已取消修改')
  } catch {
    Message.error('重新加载配置失败')
  }
}
</script>

<template>
  <div v-if="CPUData" class="h-full overflow-y-auto text-ink p-6 no-scrollbar">
    <div class="max-w-[1300px] mx-auto flex flex-col lg:flex-row gap-6">
      <!-- ==================== 左/中：CPU 设置区域 ==================== -->
      <div class="flex-1 space-y-6">
        <!-- 头部标题 -->
        <div>
          <h1 class="text-2xl font-bold tracking-wide">CPU 设置</h1>
          <p class="text-[13px] text-gray-500 mt-1">调整 CPU 的性能参数，发挥处理器最佳性能。</p>
        </div>

        <!-- 1. CPU 配置文件 -->
        <div
          class="panel-card"
        >
          <div class="flex justify-between items-center mb-4">
            <h2 class="text-[13px] font-semibold text-gray-300">CPU 配置文件</h2>
          </div>

          <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div
              v-for="p in profiles"
              :key="p.key"
              :class="[
                'border rounded-xl p-4 cursor-pointer transition-all duration-300 flex flex-col justify-between h-[96px]',
                selectedProfile === p.key
                  ? 'profile-active border-cyber-purple bg-panel-active shadow-[0_0_15px_rgba(138,43,226,0.25)]'
                  : 'border-ink/[0.05] bg-panel hover:border-ink/10',
              ]"
              @click="selectProfile(p.key)"
            >
              <span
                class="text-xs font-semibold"
                :class="selectedProfile === p.key ? 'text-ink' : 'text-gray-300'"
                >{{ p.title }}</span
              >
              <span class="text-[11px] text-gray-500">{{ p.desc }}</span>
            </div>
          </div>
        </div>

        <!-- 2. 核心设置 -->
        <div
          class="panel-card space-y-6"
        >
          <h2 class="text-[13px] font-semibold text-gray-300">核心设置</h2>

          <div class="space-y-6">
            <!-- 长时功耗限制 (PL1) -->
            <div class="space-y-2">
              <div class="flex justify-between items-center text-xs">
                <span class="text-gray-300 flex items-center gap-1"
                  >长时功耗限制 (PL1)
                  <span class="text-gray-500 cursor-pointer text-[10px] hover:text-gray-300"
                    >ⓘ</span
                  ></span
                >
                <EditableValue
                  v-model="activeProfile.CpuLongPower"
                  :max="255"
                  :min="30"
                  class="text-purple-400 font-medium font-mono"
                  unit="W"
                />
              </div>
              <a-slider v-model="activeProfile.CpuLongPower" :min="30" :max="255" class="w-full" />
            </div>

            <!-- 短时功耗限制 (PL2) -->
            <div class="space-y-2">
              <div class="flex justify-between items-center text-xs">
                <span class="text-gray-300 flex items-center gap-1"
                  >短时功耗限制 (PL2)
                  <span class="text-gray-500 cursor-pointer text-[10px] hover:text-gray-300"
                    >ⓘ</span
                  ></span
                >
                <EditableValue
                  v-model="activeProfile.CpuShortPower"
                  :max="255"
                  :min="30"
                  class="text-purple-400 font-medium font-mono"
                  unit="W"
                />
              </div>
              <a-slider v-model="activeProfile.CpuShortPower" :min="30" :max="255" class="w-full" />
            </div>

            <!-- 核心电压偏移 (Curve Optimizer): 启用分核降压后替换为文本提示, 应用时逐核心写入 -->
            <div class="space-y-2">
              <div class="flex justify-between items-center text-xs">
                <span class="text-gray-300 flex items-center gap-1"
                  >核心电压偏移 (CO)
                  <span class="text-gray-500 cursor-pointer text-[10px] hover:text-gray-300"
                    >ⓘ</span
                  ></span
                >
                <EditableValue
                  v-if="SmuData && !perCoreMode"
                  v-model="SmuData.CurveOptimizerAll"
                  :max="50"
                  :min="-50"
                  class="text-purple-400 font-medium font-mono"
                />
              </div>
              <a-slider
                v-if="SmuData && !perCoreMode"
                v-model="SmuData.CurveOptimizerAll"
                :min="-50"
                :max="50"
                class="w-full"
              />
              <div
                v-else-if="SmuData"
                class="text-[11px] text-gray-500 leading-relaxed bg-ink/[0.02] border border-ink/[0.04] rounded-lg px-3 py-2.5"
              >
                已启用分核心降压：应用设置时将逐核心写入【Ryzen SMU】页面中保存的分核心 Curve
                Optimizer 数值
              </div>
            </div>

            <!-- CPU 温度墙 -->
            <div class="space-y-2">
              <div class="flex justify-between items-center text-xs">
                <span class="text-gray-300 flex items-center gap-1"
                  >CPU 温度墙
                  <span class="text-gray-500 cursor-pointer text-[10px] hover:text-gray-300"
                    >ⓘ</span
                  ></span
                >
                <EditableValue
                  v-model="activeProfile.CpuTempWall"
                  :max="105"
                  :min="60"
                  class="text-purple-400 font-medium font-mono"
                  unit="°C"
                />
              </div>
              <a-slider v-model="activeProfile.CpuTempWall" :min="60" :max="105" class="w-full" />
            </div>

            <!-- 最大睿频频率 -->
            <div class="space-y-2">
              <div class="flex justify-between items-center text-xs">
                <span class="text-gray-300 flex items-center gap-1"
                  >最大睿频频率
                  <span class="text-gray-500 cursor-pointer text-[10px] hover:text-gray-300"
                    >ⓘ</span
                  ></span
                >
                <EditableValue
                  v-model="activeProfile.CpuMaxFrequency"
                  :max="5400"
                  :min="1000"
                  :precision="1"
                  :scale="0.001"
                  :step="100"
                  class="text-purple-400 font-medium font-mono"
                  unit="GHz"
                />
              </div>
              <a-slider
                v-model="activeProfile.CpuMaxFrequency"
                :min="1000"
                :max="5400"
                :step="100"
                class="w-full"
              />
            </div>
          </div>
        </div>
        <!-- 3. 底部全局控制栏 -->
        <div class="flex justify-between items-center pt-2">
          <button
            class="flex items-center gap-2 text-xs text-gray-400 hover:text-ink border border-ink/10 hover:border-ink/20 bg-ink/[0.02] hover:bg-ink/[0.05] px-4 py-2 rounded-lg transition-colors"
            @click="handleReset"
          >
            <!-- 刷新旋转小图标 -->
            <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M4 4v5h.582m15.356 2A8.001 8.001 0 1121.21 7.89M9 11l3-3 3 3m-3-3v12"
              />
            </svg>
            重置
          </button>

          <div class="flex gap-3">
            <button
              class="text-xs text-gray-400 hover:text-ink border border-ink/5 bg-transparent hover:bg-ink/[0.03] px-5 py-2 rounded-lg transition-colors"
              @click="handleCancel"
            >
              取消
            </button>
            <button
              :disabled="loading"
              class="text-xs font-medium text-white bg-gradient-to-r from-purple-700 to-indigo-600 hover:from-purple-600 hover:to-indigo-500 disabled:opacity-50 px-6 py-2 rounded-lg transition-all shadow-[0_0_15px_rgba(138,43,226,0.3)]"
              @click="handleApplyAll"
            >
              {{ loading ? '应用中...' : '应用' }}
            </button>
          </div>
        </div>
      </div>

      <!-- ==================== 右侧：信息与说明栏 ==================== -->
      <div class="w-full lg:w-[360px] shrink-0 space-y-6 lg:pt-[115px]">
        <!-- 1. CPU 信息卡片 -->
        <div
          class="panel-card"
        >
          <h2 class="text-[13px] font-semibold text-gray-300 mb-4">CPU 信息</h2>
          <div class="flex items-center gap-4 h-[96px]">
            <!-- 高保真 3D 芯片矢量线稿 (CpuDie) -->
            <div
              class="w-16 h-16 bg-ink/[0.02] border border-ink/[0.05] rounded-xl flex items-center justify-center relative"
            >
              <CpuDie />
            </div>

            <div class="space-y-1 text-[11px] text-gray-400">
              <div class="text-[13px] font-bold text-ink">
                {{ cpuInfo?.Name || 'Unknown CPU' }}
              </div>
              <div>{{ cpuInfo?.Cores || 0 }} 核心 / {{ cpuInfo?.Threads || 0 }} 线程</div>
              <div>
                基础频率
                {{ cpuInfo?.BaseFreqMhz ? (cpuInfo.BaseFreqMhz / 1000).toFixed(1) : 0 }} GHz
              </div>
            </div>
          </div>
        </div>

        <!-- 2. 实时状态卡片 -->
        <div
          class="panel-card space-y-4"
        >
          <h2 class="text-[13px] font-semibold text-gray-300">实时状态</h2>

          <div class="space-y-3.5">
            <div v-for="m in cpuMetrics" :key="m.label" class="space-y-1.5">
              <div class="flex justify-between text-[11px]">
                <span class="text-gray-400">{{ m.label }}</span>
                <span class="text-ink font-mono font-medium">{{ m.text }} {{ m.unit }}</span>
              </div>
              <div class="h-1.5 bg-ink/[0.03] rounded-full overflow-hidden">
                <div :class="m.barClass" :style="{ width: m.width }" class="h-full"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- 3. 核心分布卡片 -->
        <div
          class="panel-card space-y-3.5"
        >
          <div class="flex justify-between items-center">
            <h2 class="text-[13px] font-semibold text-gray-300">核心分布</h2>
          </div>

          <div class="space-y-2">
            <!-- 动态渲染所有核心 -->
            <div class="grid grid-cols-6 gap-1.5">
              <div
                v-for="i in cpuInfo?.Cores || 0"
                :key="'core' + i"
                class="core-tile bg-purple-950/20 border border-purple-500/25 rounded-lg py-2 text-center"
              >
                <div class="text-[8px] text-purple-400 leading-none">C</div>
                <div class="text-xs text-purple-300 font-bold font-mono mt-0.5">
                  {{ String(i - 1).padStart(2, '0') }}
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 4. 说明卡片 -->
        <div
          class="panel-card space-y-2.5"
        >
          <h2 class="text-[13px] font-semibold text-gray-300">说明</h2>
          <div class="text-[11px] text-gray-500 leading-relaxed space-y-2">
            <p>功耗限制决定了 CPU 可持续运行的最大功耗。</p>
            <p>电压偏移可在保证稳定性的前提下降低功耗和温度。</p>
            <p>修改设置后请点击“应用”以生效。</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div v-else class="flex items-center justify-center h-full">
    <a-spin dot />
  </div>
</template>

<style lang="scss" scoped>

/* 浅色下选中配置卡片: 淡灰底 + 灰边框, 不发光(深色保持紫调, 见模板类) */
[data-theme='light'] .profile-active {
  border-color: rgba(13, 14, 21, 0.16);
  box-shadow: none;
}

/* 浅色下核心分布磁贴: 淡灰底 + 灰边框 + 灰字(深色保持紫调) */
[data-theme='light'] .core-tile {
  background-color: rgba(13, 14, 21, 0.04);
  border-color: rgba(13, 14, 21, 0.1);
}
[data-theme='light'] .core-tile .text-purple-400 {
  color: #64708a;
}
[data-theme='light'] .core-tile .text-purple-300 {
  color: #454d61;
}
</style>
