<script setup lang="ts">
import {computed, ref} from 'vue'
import {Message} from '@arco-design/web-vue'
import {Fan} from '@/utils/bridge'
import {stopAutoFanIfRunning} from '@/utils/fanControl'
import {useConfigStore} from '@/stores/config'
import FanSpeed from '@/components/common/FanSpeed.vue'
import EditableValue from '@/components/common/EditableValue.vue'
import {FAN_MAX_RPM, FAN_MIN_RPM} from '@/constants'

const loading = ref(false)
const visible = ref(false)
const configStore = useConfigStore()

const FanPageStore = computed(() => configStore.config?.Fan)

const handleClick = () => {
  if (!FanPageStore.value) return
  if (FanPageStore.value.ManualFanSpeed > FAN_MAX_RPM || FanPageStore.value.ManualFanSpeed < FAN_MIN_RPM) {
    visible.value = true
  } else {
    handleOk()
  }
}

const handleOk = async () => {
  if (!FanPageStore.value) return
  visible.value = false
  loading.value = true
  try {
    await stopAutoFanIfRunning()
    const res = await Fan.SetFanSpeed(FanPageStore.value.ManualFanSpeed)
    if (res.Success) {
      Message.success(res.Message)
      configStore.debouncedSave()
    } else {
      Message.error(res.Message)
    }
  } catch {
    Message.error('应用失败，请检查桥接服务')
  } finally {
    loading.value = false
  }
}

const handleCancel = () => {
  visible.value = false
}

async function handleRemoveFanClick() {
  try {
    await stopAutoFanIfRunning()
    const res = await Fan.RemoveFanSpeed()
    if (res.Success) {
      Message.success(res.Message)
    } else {
      Message.error(res.Message)
    }
  } catch {
    Message.error('操作失败，请检查桥接服务')
  }
}
</script>

<template>
  <div v-if="FanPageStore" class="h-full overflow-y-auto text-ink p-6 no-scrollbar">
    <div class="max-w-[1300px] mx-auto flex flex-col lg:flex-row gap-6">
      <!-- ==================== 左侧：手动风扇控制区 ==================== -->
      <div class="flex-1 space-y-6">
        <!-- 头部标题 -->
        <div>
          <h1 class="text-2xl font-bold tracking-wide">风扇控制</h1>
          <p class="text-[13px] text-gray-500 mt-1">手动调节风扇转速或恢复自动控制</p>
        </div>

        <!-- 转速调节磨砂卡片 -->
        <div
          class="panel-card p-6"
        >
          <div class="flex flex-col gap-6">
            <div class="flex justify-between items-end">
              <div>
                <span class="text-[10px] font-bold text-purple-400 uppercase tracking-widest block"
                  >Manual Control</span
                >
                <h2 class="text-base font-semibold mt-1 text-gray-200">目标转速设定</h2>
              </div>
              <div class="text-right">
                <EditableValue
                  v-model="FanPageStore.ManualFanSpeed"
                  :max="8000"
                  :min="0"
                  :step="100"
                  class="text-3xl font-black font-mono text-ink leading-none"
                />
                <span class="text-gray-500 text-xs ml-1 font-bold font-mono">RPM</span>
              </div>
            </div>

            <!-- 自定义发光滑块 -->
            <a-slider
              v-model="FanPageStore.ManualFanSpeed"
              :min="0"
              :max="8000"
              :step="100"
              class="w-full"
            />

            <!-- 动作按钮组 -->
            <div class="grid grid-cols-2 gap-4 mt-2">
              <button
                :disabled="loading"
                class="text-xs font-semibold text-white bg-gradient-to-r from-purple-700 to-indigo-600 hover:from-purple-600 hover:to-indigo-500 disabled:opacity-50 py-2.5 rounded-lg transition-all shadow-[0_0_15px_rgba(138,43,226,0.3)]"
                @click="handleClick"
              >
                {{ loading ? '应用中...' : '应用设定' }}
              </button>
              <button
                class="text-xs font-semibold text-gray-300 hover:text-ink border border-ink/10 hover:border-ink/20 bg-ink/[0.02] hover:bg-ink/[0.05] py-2.5 rounded-lg transition-all"
                @click="handleRemoveFanClick"
              >
                移除限制
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- ==================== 右侧：实时监控与安全提醒栏 ==================== -->
      <div class="w-full lg:w-[360px] shrink-0 space-y-6 lg:pt-[115px]">
        <!-- 1. 实时状态监控（原先直接跟在下方的监控改到右侧排版） -->
        <FanSpeed />

        <!-- 2. 安全说明卡片 -->
        <div
          class="panel-card space-y-2.5 select-none"
        >
          <h2 class="text-[13px] font-semibold text-gray-300">安全提示</h2>
          <div class="text-[11px] text-gray-500 leading-relaxed space-y-2">
            <p><strong>手动设定</strong>: 会关闭自动风扇温控后台，使转速锁定在您调整的设定值上。</p>
            <p>
              <strong>高转速磨损</strong>: 长时间处于超过 5800 RPM
              极高转速可能会缩短电机寿命并产生刺耳噪音。
            </p>
            <p>
              <strong>低转速降频</strong>:
              重载时转速过低会导致处理器和图形芯片因过热而发生降频物理限速。
            </p>
          </div>
        </div>
      </div>
    </div>

    <!-- 安全警告暗色模态窗口 -->
    <a-modal
      v-model:visible="visible"
      simple
      :mask-closable="false"
      @ok="handleOk"
      @cancel="handleCancel"
    >
      <template #title>安全警告</template>
      <div class="text-[12px] text-gray-300 leading-relaxed">
        设定目标转速高于 <span class="text-rose-400 font-bold font-mono">5800 RPM</span> 或低于
        <span class="text-rose-400 font-bold font-mono">1500 RPM</span
        >，可能会引起系统噪音剧增、硬件热量积攒异常。请确认您在清楚此操作后果的前提下继续。
      </div>
    </a-modal>
  </div>

  <div v-else class="flex items-center justify-center h-full">
    <a-spin dot />
  </div>
</template>
