<script setup lang="ts">
import CpuDie from '@/components/common/CpuDie.vue'
import EditableValue from '@/components/common/EditableValue.vue'

import {computed, onMounted, onUnmounted, reactive, ref, watch} from 'vue'
import {Message} from '@arco-design/web-vue'
import {type CommandResult, CPU, RyzenSmu, type SmuTelemetry} from '@/utils/bridge'
import {useConfigStore} from '@/stores/config'
import type {SmuSectionType} from '@/types/config'
import {POLL_INTERVAL_SMU} from '@/constants'
import SparklineCard from '@/components/common/SparklineCard.vue'
import {useRingBuffer} from '@/composables/useRingBuffer'

// CONFIG_GROUPS 走 Set+key 的动态应用，仅允许数值型 Smu 字段（数组字段如 CurveOptimizerPerCore 不适用）
type NumericSmuKey = {
  [K in keyof SmuSectionType]: SmuSectionType[K] extends number ? K : never
}[keyof SmuSectionType]

interface ConfigGroupItem {
  label: string
  key: NumericSmuKey
  min: number
  max: number
  step?: number
  unit: string
  sliderClass: string
}
interface ConfigGroup {
  title: string
  items: ConfigGroupItem[]
}

const CONFIG_GROUPS: ConfigGroup[] = [
  {
    title: '功耗限制 (Power Limits)',
    items: [
      {
        label: 'STAPM 长期功耗上限',
        key: 'StapmLimit',
        min: 0,
        max: 200,
        unit: 'W',
        sliderClass: 'slider-purple',
      },
      {
        label: 'STAPM 时间窗口',
        key: 'StapmTime',
        min: 0,
        max: 3600,
        unit: 's',
        sliderClass: 'slider-purple',
      },
      {
        label: 'Fast 瞬时功耗上限',
        key: 'FastLimit',
        min: 0,
        max: 200,
        unit: 'W',
        sliderClass: 'slider-purple',
      },
      {
        label: 'Slow 持续功耗上限',
        key: 'SlowLimit',
        min: 0,
        max: 200,
        unit: 'W',
        sliderClass: 'slider-purple',
      },
      {
        label: 'Slow 功耗时间窗口',
        key: 'SlowTime',
        min: 0,
        max: 3600,
        unit: 's',
        sliderClass: 'slider-purple',
      },
      {
        label: 'PPT 功耗限制 (RSMU)',
        key: 'PptLimitRsmu',
        min: 0,
        max: 200,
        unit: 'W',
        sliderClass: 'slider-purple',
      },
    ],
  },
  {
    title: '电流限制 (Current Limits)',
    items: [
      {
        label: 'VRM 持续电流限制 (MP1)',
        key: 'VrmCurrentMp1',
        min: 0,
        max: 300000,
        step: 1000,
        unit: 'mA',
        sliderClass: 'slider-blue',
      },
      {
        label: 'VRM 持续电流限制 (RSMU)',
        key: 'VrmCurrentRsmu',
        min: 0,
        max: 300000,
        step: 1000,
        unit: 'mA',
        sliderClass: 'slider-blue',
      },
      {
        label: 'EDC 瞬间电流限制 (MP1)',
        key: 'EdcLimitMp1',
        min: 0,
        max: 300000,
        step: 1000,
        unit: 'mA',
        sliderClass: 'slider-blue',
      },
      {
        label: 'EDC 瞬间电流限制 (RSMU)',
        key: 'EdcLimitRsmu',
        min: 0,
        max: 300000,
        step: 1000,
        unit: 'mA',
        sliderClass: 'slider-blue',
      },
    ],
  },
  {
    title: '温度控制 (Thermal Control)',
    items: [
      {
        label: '温度墙限制 (MP1)',
        key: 'TempLimitMp1',
        min: 40,
        max: 115,
        unit: '℃',
        sliderClass: 'slider-red',
      },
      {
        label: '温度墙限制 (RSMU)',
        key: 'TempLimitRsmu',
        min: 40,
        max: 115,
        unit: '℃',
        sliderClass: 'slider-red',
      },
    ],
  },
  {
    title: '时钟与超频 (Clocks & OC)',
    items: [
      {
        label: 'PBO 倍率上限选择',
        key: 'PboScalar',
        min: 1,
        max: 10,
        unit: 'x',
        sliderClass: 'slider-purple',
      },
      {
        label: '超频核心频率偏移',
        key: 'OcClk',
        min: -500,
        max: 500,
        step: 25,
        unit: 'MHz',
        sliderClass: 'slider-purple',
      },
      {
        label: '超频核心电压设定',
        key: 'OcVolt',
        min: 0,
        max: 1550,
        step: 5,
        unit: 'mV',
        sliderClass: 'slider-purple',
      },
    ],
  },
]

const loadingMap = reactive<Record<string, boolean>>({})
const configStore = useConfigStore()
const smuData = computed(() => configStore.config?.Smu)

// Physical core count fetched from backend (excludes hyperthreading)
const coreCount = ref(0)
const cpuName = ref('AMD Ryzen')
const cpuCoreInfo = ref('')

const perCoreCurve = reactive<number[]>([])
const perCoreOcClk = reactive<number[]>([])

watch(
  coreCount,
  (newCount) => {
    if (newCount <= 0) return
    const saved = configStore.config?.Smu.CurveOptimizerPerCore ?? []
    const currentLen = perCoreCurve.length
    if (newCount > currentLen) {
      for (let i = currentLen; i < newCount; i++) {
        perCoreCurve.push(saved[i] ?? 0)
        perCoreOcClk.push(0)
      }
    } else if (newCount < currentLen) {
      perCoreCurve.splice(newCount)
      perCoreOcClk.splice(newCount)
    }
  },
  { immediate: true },
)

function isBootItem(key: NumericSmuKey) {
  return configStore.config?.Smu.BootApplyItems.includes(key) ?? false
}

function toggleBootItem(key: NumericSmuKey, checked: boolean | (string | number | boolean)[]) {
  const smu = configStore.config?.Smu
  if (!smu || typeof checked !== 'boolean') return
  const idx = smu.BootApplyItems.indexOf(key)
  if (checked && idx < 0) smu.BootApplyItems.push(key)
  if (!checked && idx >= 0) smu.BootApplyItems.splice(idx, 1)
  configStore.debouncedSave()
}

const applySetting = async (methodName: keyof typeof RyzenSmu, ...args: number[]) => {
  loadingMap[methodName] = true
  try {
    const fn = RyzenSmu[methodName] as unknown as (
      ...methodArgs: number[]
    ) => Promise<CommandResult>
    const res = await fn(...args)

    if (res.Success) {
      Message.success(res.Message || '应用成功')
    } else {
      Message.error(res.Message || '应用失败')
    }
    configStore.debouncedSave()
  } catch (e) {
    Message.error('应用执行失败')
    console.error(e)
  } finally {
    loadingMap[methodName] = false
  }
}

// 分核值仅在点击✓真正应用到 SMU 时写入配置，未应用的草稿值不落盘
const applyPerCoreCurve = (index: number) => {
  const value = perCoreCurve[index] ?? 0
  const smu = configStore.config?.Smu
  if (smu) {
    const saved = smu.CurveOptimizerPerCore
    while (saved.length <= index) saved.push(0)
    saved[index] = value
  }
  applySetting('SetCurveOptimizerPerCore', index, value)
}

// ====== Real-time SMU Telemetry ======
const telemetry = ref<SmuTelemetry>({ Ppt: 0, Temp: 0, FreqMhz: 0, Usage: 0 })
const pptSeries = useRingBuffer(24)
const tempSeries = useRingBuffer(24)

// 温度值颜色: >90 红 / >75 橙 / 常规
const tempValueClass = computed(() =>
  telemetry.value.Temp > 90
    ? 'text-base font-bold font-mono text-red-400'
    : telemetry.value.Temp > 75
      ? 'text-base font-bold font-mono text-orange-400'
      : 'text-base font-bold font-mono text-ink',
)

let pollingTimer: ReturnType<typeof setInterval> | null = null

async function fetchTelemetry() {
  try {
    const res = await RyzenSmu.GetSmuTelemetry()
    if (res.Success && res.Data) {
      telemetry.value = res.Data
      pptSeries.push(res.Data.Ppt)
      tempSeries.push(res.Data.Temp)
    }
  } catch (e) {
    console.warn('读取 SMU 遥测失败', e)
  }
}

onMounted(async () => {
  // Fetch real physical core count (no hyperthreading)
  try {
    const coreRes = await CPU.GetPhysicalCoreCount()
    if (coreRes.Success && coreRes.Data > 0) {
      coreCount.value = coreRes.Data
    } else {
      coreCount.value = 8 // safe fallback
    }
  } catch {
    coreCount.value = 8
  }

  // Fetch CPU name for display
  try {
    const infoRes = await CPU.GetCpuInfo()
    if (infoRes.Success && infoRes.Data) {
      cpuName.value = infoRes.Data.Name || 'AMD Ryzen'
      cpuCoreInfo.value = `${infoRes.Data.Cores} 核心 / ${infoRes.Data.Threads} 线程`
    }
  } catch (e) {
    console.warn('读取 CPU 信息失败', e)
  }

  fetchTelemetry()
  pollingTimer = setInterval(fetchTelemetry, POLL_INTERVAL_SMU)
})

onUnmounted(() => {
  if (pollingTimer) clearInterval(pollingTimer)
})
</script>

<template>
  <div v-if="smuData" class="h-full overflow-y-auto text-ink p-6 no-scrollbar">
    <div class="max-w-[1300px] mx-auto flex flex-col lg:flex-row gap-6">
      <!-- ==================== 左/中：高级电源、频率微调区 ==================== -->
      <div class="flex-1 space-y-6">
        <!-- 头部标题 -->
        <div>
          <h1 class="text-2xl font-bold tracking-wide">Ryzen SMU</h1>
          <p class="text-[13px] text-gray-500 mt-1">
            高级电源、电流及频率限制调整 (AMD Ryzen 平台专用)
          </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
          <!-- 动态生成的配置卡片（分成左右两个大组排布更整齐） -->
          <div
            v-for="group in CONFIG_GROUPS"
            :key="group.title"
            class="panel-card flex flex-col justify-between"
          >
            <div>
              <h3
                class="text-xs font-black text-purple-400 uppercase tracking-widest mb-5 border-l-4 border-purple-600 pl-2.5"
              >
                {{ group.title }}
              </h3>

              <div class="space-y-5">
                <div v-for="item in group.items" :key="item.key" class="space-y-1.5">
                  <div class="flex justify-between items-center text-[11px]">
                    <span class="text-gray-400">{{ item.label }}</span>
                    <EditableValue
                      v-model="smuData[item.key]"
                      :max="item.max"
                      :min="item.min"
                      :step="item.step || 1"
                      :unit="item.unit"
                      class="text-ink font-mono font-medium"
                    />
                  </div>
                  <div class="flex items-center gap-4">
                    <a-slider
                      v-model="smuData[item.key]"
                      :min="item.min"
                      :max="item.max"
                      :step="item.step || 1"
                      class="flex-1"
                      :class="item.sliderClass"
                    />
                    <a-checkbox
                      :model-value="isBootItem(item.key)"
                      class="boot-check shrink-0 text-[10px] text-gray-400"
                      @change="toggleBootItem(item.key, $event)"
                      >开机</a-checkbox
                    >
                    <a-button
                      type="primary"
                      size="small"
                      class="!bg-purple-600/10 !text-purple-400 !border-purple-500/20 hover:!bg-purple-600 hover:!text-white rounded-md px-3 font-semibold transition"
                      :loading="loadingMap[item.key]"
                      @click="
                        applySetting(('Set' + item.key) as keyof typeof RyzenSmu, smuData[item.key])
                      "
                      >应用</a-button
                    >
                  </div>
                </div>
              </div>
            </div>

            <!-- 仅在时钟与超频面板底部显示 OC 开关 -->
            <div
              v-if="group.title.includes('Clocks')"
              class="mt-6 flex gap-3 pt-5 border-t border-ink/[0.03]"
            >
              <a-button
                type="primary"
                class="flex-1 !rounded-lg font-bold !bg-emerald-600/20 !text-emerald-400 !border-emerald-500/20 hover:!bg-emerald-600 hover:!text-white"
                :loading="loadingMap['EnableOc']"
                @click="applySetting('EnableOc')"
                >启用超频</a-button
              >
              <a-button
                type="primary"
                class="flex-1 !rounded-lg font-bold !bg-rose-600/20 !text-rose-400 !border-rose-500/20 hover:!bg-rose-600 hover:!text-white"
                :loading="loadingMap['DisableOc']"
                @click="applySetting('DisableOc')"
                >禁用超频</a-button
              >
            </div>
          </div>
        </div>

        <!-- 下部分割栏（Curve Optimizer 与 单核超频） -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
          <!-- Curve Optimizer 面板 -->
          <div
            class="panel-card flex flex-col justify-between"
          >
            <div>
              <div class="flex justify-between items-center mb-4">
                <h3
                  class="text-xs font-black text-orange-400 uppercase tracking-widest border-l-4 border-orange-500 pl-2.5"
                >
                  Curve Optimizer 曲线优化
                </h3>
                <div class="flex items-center gap-2">
                  <span class="text-[9px] font-bold text-gray-500 uppercase">Cores</span>
                  <a-input-number
                    v-model="coreCount"
                    :min="1"
                    :max="64"
                    size="mini"
                    class="!w-12 !bg-ink/5 !border-ink/10 !text-ink rounded-md"
                    hide-button
                  />
                </div>
              </div>

              <!-- 全核偏移调节块 -->
              <div class="bg-ink/[0.02] border border-ink/[0.04] p-3.5 rounded-lg mb-4">
                <div class="flex justify-between items-center mb-1 text-[11px]">
                  <span class="font-bold text-gray-300">All Core Offset (全核心偏移量)</span>
                  <EditableValue
                    v-model="smuData.CurveOptimizerAll"
                    :max="100"
                    :min="-100"
                    class="font-mono text-orange-400 font-semibold"
                  />
                </div>
                <div class="flex items-center gap-4">
                  <a-slider
                    v-model="smuData.CurveOptimizerAll"
                    :min="-100"
                    :max="100"
                    class="flex-1 slider-orange"
                  />
                  <a-button
                    type="primary"
                    size="small"
                    class="!bg-orange-600/10 !text-orange-400 !border-orange-500/25 hover:!bg-orange-600 hover:!text-white rounded-md px-3 font-semibold transition"
                    :loading="loadingMap['SetCurveOptimizerAll']"
                    @click="applySetting('SetCurveOptimizerAll', smuData.CurveOptimizerAll)"
                    >应用</a-button
                  >
                </div>
              </div>

              <!-- 单核优化矩阵 -->
              <div class="grid grid-cols-2 gap-2 max-h-[160px] overflow-y-auto no-scrollbar">
                <div
                  v-for="(_, index) in perCoreCurve"
                  :key="index"
                  class="bg-ink/[0.02] p-2.5 rounded-lg border border-ink/[0.03] flex items-center justify-between"
                >
                  <span class="text-[9px] font-bold text-gray-500 uppercase">CORE {{ index }}</span>
                  <div class="flex items-center gap-1.5">
                    <a-input-number
                      v-model="perCoreCurve[index]"
                      :min="-50"
                      :max="50"
                      size="mini"
                      class="!w-10 !bg-transparent !border-none !text-ink p-0 text-center font-mono"
                      hide-button
                    />
                    <button
                      class="w-5 h-5 bg-orange-600/10 text-orange-400 hover:bg-orange-600 hover:text-white transition-colors border border-orange-500/20 rounded flex items-center justify-center text-[10px]"
                      @click="applyPerCoreCurve(index)"
                    >
                      ✓
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Per Core OC Clocks 面板 -->
          <div
            class="panel-card flex flex-col justify-between"
          >
            <div>
              <h3
                class="text-xs font-black text-blue-400 uppercase tracking-widest mb-4 border-l-4 border-blue-500 pl-2.5"
              >
                Per Core OC Clocks (单核超频限制)
              </h3>

              <div class="grid grid-cols-2 gap-2 max-h-[240px] overflow-y-auto no-scrollbar">
                <div
                  v-for="(_, index) in perCoreOcClk"
                  :key="index"
                  class="bg-ink/[0.02] p-2.5 rounded-lg border border-ink/[0.03] flex items-center justify-between"
                >
                  <span class="text-[9px] font-bold text-gray-500 uppercase">CORE {{ index }}</span>
                  <div class="flex items-center gap-1.5">
                    <a-input-number
                      v-model="perCoreOcClk[index]"
                      :min="0"
                      :max="1000"
                      :step="25"
                      size="mini"
                      class="!w-12 !bg-transparent !border-none !text-ink p-0 text-center font-mono"
                      hide-button
                    />
                    <button
                      class="w-5 h-5 bg-blue-600/10 text-blue-400 hover:bg-blue-600 hover:text-white transition-colors border border-blue-500/20 rounded flex items-center justify-center text-[10px]"
                      @click="applySetting('SetPerCoreOcClk', index, perCoreOcClk[index] ?? 0)"
                    >
                      ✓
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- ==================== 右侧：处理器信息与电源遥测栏 ==================== -->
      <div class="w-full lg:w-[360px] shrink-0 space-y-6 lg:pt-[115px]">
        <!-- 1. AMD Ryzen 处理器芯片详情 -->
        <div
          class="panel-card"
        >
          <h2 class="text-[13px] font-semibold text-gray-300 mb-4">Ryzen 芯片架构</h2>
          <div class="flex items-center gap-4">
            <!-- AM5 Socket 异形芯片 SVG 绘制 -->
            <div
              class="w-16 h-16 bg-ink/[0.02] border border-ink/[0.05] rounded-xl flex items-center justify-center relative shrink-0"
            >
                            <CpuDie />
            </div>

            <div class="space-y-1 text-[11px] text-gray-400">
              <div class="text-[13px] font-bold text-ink">
                <span v-if="cpuName">{{ cpuName }}</span>
                <span v-else class="text-gray-600 animate-pulse">检测中...</span>
              </div>
              <div>AMD Ryzen 架构 / AM5 接口</div>
              <div>
                <span v-if="cpuCoreInfo">{{ cpuCoreInfo }}</span>
                <span v-else class="text-gray-600 animate-pulse">{{
                  coreCount > 0 ? `${coreCount} 物理核心` : '检测中...'
                }}</span>
              </div>
              <div>Curve Optimizer 已加载 {{ coreCount }} 核</div>
              <div>支持 PBO2 曲线优化</div>
            </div>
          </div>
        </div>

        <!-- 2. 电源实时监视器（遥测 PPT / 温度波形图） -->
        <div
          class="panel-card space-y-4"
        >
          <div class="flex items-center justify-between">
            <h2 class="text-[13px] font-semibold text-gray-300">SMU 电源遥测</h2>
            <span
              class="text-[10px] text-gray-600 bg-ink/[0.03] border border-ink/[0.05] px-2 py-0.5 rounded-full"
              >{{ telemetry.FreqMhz }} MHz · {{ telemetry.Usage }}% 负载</span
            >
          </div>

          <div class="grid grid-cols-2 gap-3">
            <SparklineCard
              :gradient-opacity="0.35"
              :history="pptSeries.buffer"
              :max="150"
              :stroke-width="1.5"
              :value="telemetry.Ppt.toFixed(1)"
              color="#8A2BE2"
              gradient-id="smu-sg-ppt"
              label="PPT 封装功耗"
              svg-class="w-full h-8 opacity-80 mt-1"
              unit="W"
            />
            <SparklineCard
              :gradient-opacity="0.35"
              :history="tempSeries.buffer"
              :max="110"
              :stroke-width="1.5"
              :value="telemetry.Temp.toFixed(1)"
              :value-class="tempValueClass"
              color="#EF4444"
              gradient-id="smu-sg-temp"
              label="核心温度"
              svg-class="w-full h-8 opacity-80 mt-1"
              unit="°C"
            />
          </div>
        </div>

        <!-- 3. 技术名释说明 -->
        <div
          class="panel-card space-y-2.5"
        >
          <h2 class="text-[13px] font-semibold text-gray-300">名词解释</h2>
          <div class="text-[11px] text-gray-500 leading-relaxed space-y-2">
            <p>
              <strong>STAPM</strong>: 根据设备表面温度自适应调整 CPU
              功耗分配（在移动端设备和掌机上尤为明显）。
            </p>
            <p>
              <strong>Curve Optimizer (PBO2)</strong>:
              通过调校不同内核的电压频率曲线（降压超频），能实现在更低温度下达到更高运行频率的目标。
            </p>
            <p>
              <strong>RSMU / MP1</strong>:
              芯片内部不同模块的系统级微处理器，两者的限制参数相互协调限制。
            </p>
          </div>
          <a
            target="_blank"
            href="https://www.amd.com/zh-cn/developer/browse-by-resource-type/documentation.html"
            class="text-[11px] text-blue-400 hover:text-blue-300 cursor-pointer pt-1 flex items-center gap-0.5 font-medium transition-colors"
          >
            参考 AMD PBO 手册
          </a>
        </div>
      </div>
    </div>
  </div>
  <div v-else class="flex items-center justify-center h-full">
    <a-spin dot />
  </div>
</template>

<style scoped lang="scss">
/* no-scrollbar 与分色滑条样式已上移至 assets/Global.scss */

.boot-check {
  --primary-6: 138, 43, 226;
}
.boot-check :deep(.arco-checkbox-label) {
  color: inherit;
  font-size: 10px;
}
.boot-check :deep(.arco-checkbox-icon) {
  background-color: transparent;
  border-color: var(--color-line);
}
.boot-check:hover :deep(.arco-checkbox-icon) {
  border-color: var(--color-accent-purple);
}
.boot-check:hover :deep(.arco-checkbox-icon-hover::before),
.boot-check:focus-within :deep(.arco-checkbox-icon-hover::before) {
  background-color: var(--color-line-soft);
}
</style>
