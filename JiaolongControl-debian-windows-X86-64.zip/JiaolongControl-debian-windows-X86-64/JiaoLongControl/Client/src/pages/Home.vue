<script setup lang="ts">
import {computed, onMounted, onUnmounted, ref} from 'vue'
import VChart from 'vue-echarts'
import {use} from 'echarts/core'
import {CanvasRenderer} from 'echarts/renderers'
import {LineChart} from 'echarts/charts'
import {GridComponent, LegendComponent, TooltipComponent} from 'echarts/components'
import {PerformanceMode, SystemInfo, SystemPerMode} from '@/utils/bridge'
import {useSystemInfoStore} from '@/stores/systemInfo'
import {chartTheme} from '@/theme/theme'
import {timing} from '@/utils/timing'
import {storeToRefs} from 'pinia'
import {Message} from '@arco-design/web-vue'
import imgCPU from '@/assets/icon/iconCPU.png'
import imgGPU from '@/assets/icon/gpu2.png'
import imgFan from '@/assets/icon/iconFan.png'
import iconQuiet from '@/assets/icon/iconQuiet.png'
import iconBalanced from '@/assets/icon/iconBalanced.png'
import iconPerformance from '@/assets/icon/iconPerformance.png'
import PerformanceModeComp from './Home/PerformanceMode.vue'
import CoreMonitoringComp from './Home/CoreMonitoring.vue'
import WelcomeBannerComp from './Home/WelcomeBanner.vue'

use([CanvasRenderer, LineChart, GridComponent, TooltipComponent, LegendComponent])

const systemInfoStore = useSystemInfoStore()
const { cpuTemp, gpuTemp, fanSpeed } = storeToRefs(systemInfoStore)

const performanceModes = ref([
  { id: SystemPerMode.PerformanceMode, name: '高性能', icon: iconPerformance, active: false },
  { id: SystemPerMode.BalanceMode, name: '平衡', icon: iconBalanced, active: false },
  { id: SystemPerMode.QuietMode, name: '静音', icon: iconQuiet, active: false },
])

const activeMode = computed(
  () => performanceModes.value.find((m) => m.active) || { name: '高性能', icon: iconPerformance },
)

async function fetchPerformanceMode() {
  try {
    const res = await PerformanceMode.Get()
    if (res.Success) {
      performanceModes.value.forEach((e) => {
        e.active = e.id === res.Data
      })
    }
  } catch (e) {
    console.error(e)
  }
}

async function setMode(id: SystemPerMode) {
  const previous = performanceModes.value.map((m) => m.active)
  performanceModes.value.forEach((m) => {
    m.active = m.id === id
  })
  try {
    const res = await PerformanceMode.Set(id)
    if (!res.Success) {
      performanceModes.value.forEach((m, i) => {
        m.active = previous[i] ?? false
      })
      Message.error(res.Message || '性能模式切换失败')
    }
  } catch {
    performanceModes.value.forEach((m, i) => {
      m.active = previous[i] ?? false
    })
    Message.error('性能模式切换失败')
  }
}

const cpuUsage = computed(() => systemInfoStore.cpuStats?.Usage ?? 0)
const gpuUsage = computed(() => systemInfoStore.gpuUtilization)
const maxFanRpm = computed(() => Math.max(fanSpeed.value.CPUFanSpeed, fanSpeed.value.GPUFanSpeed))
// 无噪音传感器: 以风扇转速查表估算 (标定: 3000 RPM≈25 dBA, 4800 RPM≈40 dBA)
const NOISE_CALIBRATION: Array<[rpm: number, dba: number]> = [
  [1500, 19],
  [3000, 25],
  [4800, 40],
  [5800, 45],
  [6800, 48],
]
const noiseLevel = computed(() => {
  const rpm = maxFanRpm.value
  const pts = NOISE_CALIBRATION
  if (rpm <= pts[0]![0]) return pts[0]![1]
  for (let i = 1; i < pts.length; i++) {
    const [hiRpm, hiDba] = pts[i]!
    if (rpm <= hiRpm) {
      const [loRpm, loDba] = pts[i - 1]!
      return Math.round(loDba + ((rpm - loRpm) / (hiRpm - loRpm)) * (hiDba - loDba))
    }
  }
  return pts[pts.length - 1]![1]
})

const sysCpuName = ref('Loading...')
const sysGpuName = ref('Loading...')
const sysMemory = ref('Loading...')
const sysOs = ref('Loading...')

// 温度历史数据
const TEMP_HISTORY_LEN = 10
const tempHistory = ref<{ cpu: number | null; gpu: number | null }[]>(
  Array.from({ length: TEMP_HISTORY_LEN }, () => ({ cpu: null, gpu: null })),
)

// 心电图数据与生成逻辑
const ecgData = ref<number[]>(Array(50).fill(30))
let ecgIndex = 0
const ecgPattern = [0, 0, 0, 0, -2, 2, -25, 12, -2, -6, 0, 0, 0, 0, 0, 0]

function tickEcg() {
  const offset = ecgPattern[ecgIndex] ?? 0
  ecgIndex = (ecgIndex + 1) % ecgPattern.length
  const noise = (Math.random() - 0.5) * 1.5
  const nextY = 30 + offset + noise
  ecgData.value.push(nextY)
  if (ecgData.value.length > 50) {
    ecgData.value.shift()
  }
}

const ecgPointsString = computed(() => {
  return ecgData.value
    .map((y, i) => {
      const x = (i / (ecgData.value.length - 1)) * 300
      return `${x.toFixed(1)},${y.toFixed(1)}`
    })
    .join(' ')
})

async function fetchStaticInfo() {
  try {
    const res = await SystemInfo.GetSystemOverview()
    if (res.Success && res.Data) {
      sysCpuName.value = res.Data.CpuName
      sysGpuName.value = res.Data.GpuName
      sysMemory.value = res.Data.MemoryInfo
      sysOs.value = res.Data.OsVersion
    }
  } catch (e) {
    console.error('Failed to fetch system info', e)
  }
}

let ecgTimer: ReturnType<typeof setInterval> | null = null
let historyTimer: ReturnType<typeof setInterval> | null = null

function startTimers() {
  stopTimers()
  ecgTimer = setInterval(tickEcg, 100)
  historyTimer = setInterval(() => {
    tempHistory.value.push({ cpu: cpuTemp.value, gpu: gpuTemp.value })
    if (tempHistory.value.length > TEMP_HISTORY_LEN) tempHistory.value.shift()
  }, 2000)
}

function stopTimers() {
  if (ecgTimer) {
    clearInterval(ecgTimer)
    ecgTimer = null
  }
  if (historyTimer) {
    clearInterval(historyTimer)
    historyTimer = null
  }
}

function handleVisibilityChange() {
  if (document.hidden) {
    stopTimers()
  } else {
    startTimers()
  }
}

onMounted(() => {
  timing('Home onMounted')
  fetchStaticInfo()
  fetchPerformanceMode()
  startTimers()
  document.addEventListener('visibilitychange', handleVisibilityChange)
})

onUnmounted(() => {
  stopTimers()
  document.removeEventListener('visibilitychange', handleVisibilityChange)
})

// 2. 温度曲线 - 折线图
const lineChartOption = computed(() => ({
  grid: { top: 30, bottom: 20, left: 35, right: 10 },
  legend: {
    data: ['CPU', 'GPU'],
    icon: 'roundRect',
    itemWidth: 12,
    itemHeight: 4,
    textStyle: { color: chartTheme.value.legend, fontSize: 10 },
    top: 0,
  },
  xAxis: {
    type: 'category',
    data: Array(TEMP_HISTORY_LEN).fill(''),
    axisLine: { show: false },
    axisTick: { show: false },
    axisLabel: { color: chartTheme.value.axis, fontSize: 10, margin: 12 },
  },
  yAxis: {
    type: 'value',
    min: 0,
    max: 100,
    interval: 25,
    splitLine: { lineStyle: { color: chartTheme.value.line } },
    axisLabel: { color: chartTheme.value.axis, fontSize: 10, formatter: '{value}°C' },
  },
  series: [
    {
      name: 'CPU',
      data: tempHistory.value.map((i) => i.cpu),
      type: 'line',
      smooth: true,
      symbol: 'circle',
      symbolSize: 6,
      lineStyle: { color: '#3B82F6', width: 3 },
      itemStyle: { color: '#3B82F6' },
    },
    {
      name: 'GPU',
      data: tempHistory.value.map((i) => i.gpu),
      type: 'line',
      smooth: true,
      symbol: 'circle',
      symbolSize: 6,
      lineStyle: { color: '#10B981', width: 3 },
      itemStyle: { color: '#10B981' },
    },
  ],
}))
</script>

<template>
  <div class="p-6 h-full overflow-y-auto space-y-6 text-ink no-scrollbar">
    <!-- Row 1: 顶部 Banner -->
    <WelcomeBannerComp
      :cpu-temp="cpuTemp"
      :gpu-temp="gpuTemp"
      :active-mode-name="activeMode.name"
      :active-mode-icon="activeMode.icon"
    />

    <!-- Row 2: 模式 & 监控 -->
    <div class="grid grid-cols-12 gap-3 h-[250px]">
      <PerformanceModeComp :modes="performanceModes" @change-mode="setMode" />
      <CoreMonitoringComp
        :cpu-usage="cpuUsage"
        :gpu-usage="gpuUsage"
        :cpu-temp="cpuTemp"
        :gpu-temp="gpuTemp"
      />
    </div>

    <!-- Row 3: 系统概览 & 风扇 & 曲线 -->
    <div class="grid grid-cols-12 gap-6 h-[280px]">
      <!-- 系统概览 -->
      <div class="col-span-4 glass-card p-6 flex flex-col">
        <h2 class="text-[15px] font-medium text-ink/90 mb-4">系统概览</h2>
        <div class="flex-1 flex flex-col justify-between">
          <div class="flex items-center gap-4">
            <div
              class="badge-blue w-8 h-8 rounded-full flex items-center justify-center text-blue-500"
            >
              <span
                class="icon-mask icon-tint-blue w-4 h-4"
                :style="{ WebkitMaskImage: `url(${imgCPU})`, maskImage: `url(${imgCPU})` }"
              ></span>
            </div>
            <div>
              <div class="text-xs text-ink/90">CPU</div>
              <div class="text-xs text-gray-500 mt-0.5">{{ sysCpuName }}</div>
            </div>
          </div>
          <div class="flex items-center gap-4">
            <div
              class="badge-green w-8 h-8 rounded-full flex items-center justify-center text-green-500"
            >
              <span
                class="icon-mask icon-tint-green w-4 h-4"
                :style="{ WebkitMaskImage: `url(${imgGPU})`, maskImage: `url(${imgGPU})` }"
              ></span>
            </div>
            <div>
              <div class="text-xs text-ink/90">GPU</div>
              <div class="text-xs text-gray-500 mt-0.5">{{ sysGpuName }}</div>
            </div>
          </div>
          <div class="flex items-center gap-4">
            <div
              class="badge-yellow w-8 h-8 rounded-full flex items-center justify-center text-yellow-500"
            >
              <icon-storage />
            </div>
            <div>
              <div class="text-xs text-ink/90">内存</div>
              <div class="text-xs text-gray-500 mt-0.5">{{ sysMemory }}</div>
            </div>
          </div>
          <div class="flex items-center gap-4">
            <div
              class="badge-red w-8 h-8 rounded-full flex items-center justify-center text-red-500"
            >
              <icon-computer />
            </div>
            <div>
              <div class="text-xs text-ink/90">系统</div>
              <div class="text-xs text-gray-500 mt-0.5">{{ sysOs }}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- 风扇与噪音 -->
      <div class="col-span-4 glass-card p-6 flex flex-col">
        <h2 class="text-[15px] font-medium text-ink/90 mb-4">风扇与噪音</h2>

        <div class="flex items-center gap-4 mb-6">
          <div
            class="badge-neutral w-12 h-12 rounded-full flex items-center justify-center overflow-hidden"
          >
            <span
              class="icon-mask icon-tint-blue-bright w-7 h-7 animate-spin"
              style="animation-duration: 3s"
              :style="{ WebkitMaskImage: `url(${imgFan})`, maskImage: `url(${imgFan})` }"
            ></span>
          </div>
          <div>
            <div class="flex items-baseline gap-1">
              <span class="text-3xl font-semibold">{{ maxFanRpm }}</span>
              <span class="text-xs text-gray-400">RPM</span>
            </div>
            <div class="text-xs text-gray-500">风扇转速</div>
          </div>
        </div>

        <!-- 模拟心电图 (ECG) -->
        <div class="h-16 flex items-center justify-center mb-6 overflow-hidden">
          <svg class="w-full h-full" viewBox="0 0 300 60" preserveAspectRatio="none">
            <defs>
              <!-- 水平方向渐变色，从紫色过渡到蓝色，再到浅绿 -->
              <linearGradient id="ecgGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#8A2BE2" stop-opacity="0.3" />
                <stop offset="50%" stop-color="#3B82F6" stop-opacity="0.8" />
                <stop offset="100%" stop-color="#10B981" stop-opacity="1" />
              </linearGradient>
              <!-- 霓虹发光滤镜 -->
              <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="1.2" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>
            <polyline
              fill="none"
              stroke="url(#ecgGrad)"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
              filter="url(#glow)"
              :points="ecgPointsString"
            />
          </svg>
        </div>

        <div class="mt-auto">
          <div class="flex items-baseline gap-1">
            <span class="text-2xl font-semibold">{{ noiseLevel }}</span>
            <span class="text-xs text-gray-400">dBA</span>
          </div>
          <div class="text-xs text-gray-500">当前噪音 (估算)</div>
        </div>
      </div>

      <!-- 温度曲线 -->
      <div class="col-span-4 glass-card p-6 flex flex-col">
        <h2 class="text-[15px] font-medium text-ink/90 mb-2">温度曲线</h2>
        <div class="flex-1">
          <VChart :option="lineChartOption" autoresize />
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.echarts {
  width: 100%;
  height: 100%;
}
</style>
